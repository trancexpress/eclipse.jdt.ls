package dsl;

import org.eclipse.jdt.ls.core.internal.handlers.CompletionHandler;
import org.eclipse.jdt.ls.core.internal.handlers.InitHandler;
import org.eclipse.jdt.ls.core.internal.handlers.JDTLanguageServer;
import org.eclipse.jdt.ls.core.internal.handlers.WorkspaceDiagnosticsHandler;
import org.eclipse.jdt.ls.core.internal.handlers.WorkspaceExecuteCommandHandler;
import org.eclipse.jdt.ls.core.internal.managers.ProjectsManager;
import org.eclipse.jdt.ls.core.internal.managers.TelemetryManager;
import org.eclipse.jdt.ls.core.internal.preferences.PreferenceManager;

public class DslLanguageServer extends JDTLanguageServer {

	private final ProjectsManager pm;
	private final PreferenceManager preferenceManager;
	private final TelemetryManager telemetryManager;

	public DslLanguageServer(ProjectsManager projects, PreferenceManager preferenceManager, TelemetryManager telemetryManager) {
		super(projects, preferenceManager, telemetryManager);
		this.pm = projects;
		this.preferenceManager = preferenceManager;
		this.telemetryManager = telemetryManager;
	}


    @Override
    public CompletionHandler createCompletionHandler(PreferenceManager preferences) {
        return new DslCompletionHandler(preferences);
    }

    @Override
    public InitHandler createInitHandler() {
        return new DslInitHandler(pm, preferenceManager, client, WorkspaceExecuteCommandHandler.getInstance(), telemetryManager);
    }

    @Override
    public WorkspaceDiagnosticsHandler createWorkspaceDiagnosticsHandler() {
        return new DslWorkspaceDiagnosticsHandler(client, pm, preferenceManager.getClientPreferences(), getDocumentLifeCycleHandler());
    }
}
