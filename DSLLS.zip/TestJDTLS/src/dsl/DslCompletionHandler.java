package dsl;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.ls.core.internal.handlers.CompletionHandler;
import org.eclipse.jdt.ls.core.internal.preferences.PreferenceManager;
import org.eclipse.lsp4j.CompletionList;
import org.eclipse.lsp4j.CompletionParams;

public class DslCompletionHandler extends CompletionHandler {

	public DslCompletionHandler(PreferenceManager manager) {
		super(manager);
	}

	@Override
	public CompletionList completeContentAssist(CompletionParams params, IProgressMonitor monitor) throws JavaModelException {
		return super.completeContentAssist(params, monitor);
	}
}
