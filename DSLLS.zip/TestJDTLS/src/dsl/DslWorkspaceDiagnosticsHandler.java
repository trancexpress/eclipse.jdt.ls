package dsl;

import java.util.Arrays;
import java.util.Collections;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IMarkerDelta;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceDelta;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.Platform;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.ls.core.internal.JDTUtils;
import org.eclipse.jdt.ls.core.internal.JavaClientConnection;
import org.eclipse.jdt.ls.core.internal.JavaLanguageServerPlugin;
import org.eclipse.jdt.ls.core.internal.ResourceUtils;
import org.eclipse.jdt.ls.core.internal.handlers.BaseDiagnosticsHandler;
import org.eclipse.jdt.ls.core.internal.handlers.DocumentLifeCycleHandler;
import org.eclipse.jdt.ls.core.internal.handlers.JsonRpcHelpers;
import org.eclipse.jdt.ls.core.internal.handlers.WorkspaceDiagnosticsHandler;
import org.eclipse.jdt.ls.core.internal.managers.ProjectsManager;
import org.eclipse.jdt.ls.core.internal.preferences.ClientPreferences;
import org.eclipse.jface.text.IDocument;
import org.eclipse.lsp4j.PublishDiagnosticsParams;

public class DslWorkspaceDiagnosticsHandler extends WorkspaceDiagnosticsHandler {

	private final JavaClientConnection connection;
	private final ProjectsManager projectsManager;
	private final DocumentLifeCycleHandler handler;
	private final boolean isDiagnosticTagSupported;

	public DslWorkspaceDiagnosticsHandler(JavaClientConnection connection, ProjectsManager projectsManager, ClientPreferences prefs, DocumentLifeCycleHandler handler) {
		super(connection, projectsManager, prefs, handler);
		this.connection = connection;
		this.projectsManager = projectsManager;
		this.handler = handler;
		this.isDiagnosticTagSupported = prefs != null ? prefs.isDiagnosticTagSupported() : false;
	}

	// Can just call extra code and then super? to avoid all the copying...
	@Override
	public boolean visit(IResourceDelta delta) throws CoreException {
		if (delta.getFlags() == IResourceDelta.MARKERS && Arrays.stream(delta.getMarkerDeltas()).map(IMarkerDelta::getMarker).noneMatch(WorkspaceDiagnosticsHandler::isInteresting)) {
			return false;
		}
		IResource resource = delta.getResource();
		if (resource == null) {
			return false;
		}
		if (resource.getType() == IResource.FOLDER || resource.getType() == IResource.ROOT) {
			return true;
		}
		// WorkspaceEventsHandler only handles the case of deleting the specific file and removes it's diagnostics.
		// If delete a folder directly, no way to clean up the diagnostics for it's children.
		// The resource delta visitor will make sure to clean up all stale diagnostics.
		if (!resource.isAccessible()) { // Check if resource is accessible.
			if (isSupportedDiagnosticsResource(resource)) {
				cleanUpDiagnostics(resource);
				return resource.getType() == IResource.PROJECT;
			}

			// If delete a project folder directly, make sure to clean up its build file diagnostics.
			if (projectsManager.isBuildLikeFileName(resource.getName())) {
				cleanUpDiagnostics(resource);
				if(!resource.getParent().isAccessible()) { // Clean up the project folder diagnostics.
					cleanUpDiagnostics(resource.getParent(), Platform.OS_WIN32.equals(Platform.getOS()));
				}
			}

			return false;
		}
		if (resource.getType() == IResource.PROJECT) {
			// ignore problems caused by standalone files (problems in the default project)
			if (ProjectsManager.getDefaultProject().equals(resource.getProject())) {
				return false;
			}
			IProject project = (IProject) resource;
			// report problems for other projects
			IMarker[] markers = project.findMarkers(null, true, IResource.DEPTH_ZERO);
			publishMarkers(project, markers);
			return true;
		}
		// No marker changes continue to visit
		if ((delta.getFlags() & IResourceDelta.MARKERS) == 0) {
			return false;
		}
		IFile file = (IFile) resource;
		IDocument document = null;
		IMarker[] markers = null;
		// Check if it is a Java ...
		if (JavaCore.isJavaLikeFileName(file.getName())) {
			ICompilationUnit cu = (ICompilationUnit) JavaCore.create(file);
			// Clear the diagnostics for the resource not on the classpath
			IJavaProject javaProject = cu.getJavaProject();
			if (javaProject == null || !javaProject.isOnClasspath(cu)) {
				String uri = JDTUtils.getFileURI(resource);
				this.connection.publishDiagnostics(new PublishDiagnosticsParams(ResourceUtils.toClientUri(uri), Collections.emptyList()));
				return false;
			}
			if (!cu.isWorkingCopy()) {
				markers = resource.findMarkers(null, false, IResource.DEPTH_ONE);
				try {
					document = JsonRpcHelpers.toDocument(cu.getBuffer());
				} catch (JavaModelException e) {
					// do nothing
				}
			} else if (handler != null) {
				handler.triggerValidation(cu);
			}
		} // or a build file
		else if (projectsManager.isBuildFile(file)) {
			//all errors on that build file should be relevant
			markers = file.findMarkers(null, true, 1);
			document = JsonRpcHelpers.toDocument(file);
		}
		if (document != null) {
			String uri = JDTUtils.getFileURI(resource);
			if (!BaseDiagnosticsHandler.matchesDiagnosticFilter(uri, JavaLanguageServerPlugin.getPreferencesManager().getPreferences().getDiagnosticFilter())) {
				this.connection.publishDiagnostics(new PublishDiagnosticsParams(ResourceUtils.toClientUri(uri), toDiagnosticsArray(document, markers, isDiagnosticTagSupported)));
			}
		}
		return false;
	}
}
