package dsl;

import java.util.List;

import org.eclipse.jdt.ls.core.internal.JavaClientConnection;
import org.eclipse.jdt.ls.core.internal.handlers.InitHandler;
import org.eclipse.jdt.ls.core.internal.handlers.WorkspaceExecuteCommandHandler;
import org.eclipse.jdt.ls.core.internal.managers.ProjectsManager;
import org.eclipse.jdt.ls.core.internal.managers.TelemetryManager;
import org.eclipse.jdt.ls.core.internal.preferences.PreferenceManager;
import org.eclipse.lsp4j.DocumentFilter;
import org.eclipse.lsp4j.FileOperationFilter;
import org.eclipse.lsp4j.FileOperationOptions;
import org.eclipse.lsp4j.FileOperationPattern;
import org.eclipse.lsp4j.FileOperationPatternKind;
import org.eclipse.lsp4j.FileOperationsServerCapabilities;
import org.eclipse.lsp4j.InitializeResult;
import org.eclipse.lsp4j.SemanticTokensWithRegistrationOptions;
import org.eclipse.lsp4j.ServerCapabilities;
import org.eclipse.lsp4j.WorkspaceServerCapabilities;

public class DslInitHandler extends InitHandler {

    private final PreferenceManager preferenceManager;

    DslInitHandler(ProjectsManager manager, PreferenceManager preferenceManager, JavaClientConnection connection, WorkspaceExecuteCommandHandler commandHandler, TelemetryManager telemetryManager) {
        super(manager, preferenceManager, connection, commandHandler, telemetryManager);
        this.preferenceManager = preferenceManager;
    }

    @Override
    public void registerCapabilities(InitializeResult initializeResult) {
        super.registerCapabilities(initializeResult);
        ServerCapabilities capabilities = initializeResult.getCapabilities();
        if (preferenceManager.getClientPreferences().isWorkspaceWillRenameFilesSupported()) {
            FileOperationsServerCapabilities wsFileOperations = new FileOperationsServerCapabilities();
            FileOperationPattern fileOpPatternJava = new FileOperationPattern("**/*.java");
            fileOpPatternJava.setMatches(FileOperationPatternKind.File);
            FileOperationPattern fileOpPatternPackage = new FileOperationPattern("**");
            fileOpPatternPackage.setMatches(FileOperationPatternKind.Folder);
            FileOperationOptions fileOperationOptions = new FileOperationOptions(List.of(

                new FileOperationFilter(new FileOperationPattern("**/*.dsl"), "file"),

                new FileOperationFilter(fileOpPatternJava, "file"),
                new FileOperationFilter(fileOpPatternPackage, "file")
            ));
            wsFileOperations.setWillRename(fileOperationOptions);
            WorkspaceServerCapabilities wsCapabilities = capabilities.getWorkspace();
            wsCapabilities.setFileOperations(wsFileOperations);
            capabilities.setWorkspace(wsCapabilities);
        }
        SemanticTokensWithRegistrationOptions semanticTokensProvider = capabilities.getSemanticTokensProvider();
        DocumentFilter[] filters = {

                new DocumentFilter("dsl", "file", null),

                new DocumentFilter("java", "file", null),
                new DocumentFilter("java", "jdt", null),
        };
        semanticTokensProvider.setDocumentSelector(List.of(filters));
        capabilities.setSemanticTokensProvider(semanticTokensProvider);
    }
}
