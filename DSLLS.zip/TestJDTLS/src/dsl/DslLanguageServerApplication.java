package dsl;

import java.io.IOException;

import org.eclipse.equinox.app.IApplicationContext;
import org.eclipse.jdt.ls.core.internal.BaseJDTLanguageServer;
import org.eclipse.jdt.ls.core.internal.JavaLanguageServerPlugin;
import org.eclipse.jdt.ls.core.internal.LanguageServerApplication;
import org.eclipse.jdt.ls.core.internal.ProjectUtils;
import org.eclipse.jdt.ls.core.internal.handlers.WorkspaceExecuteCommandHandler;
import org.eclipse.jdt.ls.core.internal.managers.TelemetryManager;

/**
 * The application we run from patched {@code vscode-java}.
 */
public class DslLanguageServerApplication extends LanguageServerApplication {

    @Override
    public Object start(IApplicationContext context) throws Exception {
        return super.start(context);
    }

    @Override
	protected void startLanguageServer() throws IOException {
    	JavaLanguageServerPlugin jlsp = JavaLanguageServerPlugin.getInstance();
		TelemetryManager telemetryManager = new TelemetryManager();
		boolean firstTimeInitialization = ProjectUtils.getAllProjects().length == 0;
		telemetryManager.onLanguageServerStart(System.currentTimeMillis(), firstTimeInitialization);
    	BaseJDTLanguageServer ls = new DslLanguageServer(jlsp .getProjectsManager(), jlsp.getPreferencesManager(), telemetryManager);
    	JavaLanguageServerPlugin.startLanguageServer(this, ls);
	}
}
